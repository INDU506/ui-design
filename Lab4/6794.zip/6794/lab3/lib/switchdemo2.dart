class switchdemo2{
String Scase(String color){
	return (switch(color){
		'red'||'Red'||'RED'         =>"this is red",
		'blue'||'Blue'||'BLUE'      =>"this is blue",
		'green'||'Green'||'GREEN'   =>"this is green",
		'yellow'||'Yellow'||'YELLOW' =>"this is yellow",
			    _                =>"this is not listed",
		});   }
}