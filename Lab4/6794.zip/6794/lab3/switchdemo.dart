class switchdemo3 {
	void Sdemo(String name){
		first:
		
		switch(name){
			case 'apple':
				print("apple is listed");
				break;
			case 'banana':
				print("banana is listed");
				break;
			case 'cherry':
				print("cherry is listed");
				break;
			default:
				print("this is not listed");    
				}
			}
}